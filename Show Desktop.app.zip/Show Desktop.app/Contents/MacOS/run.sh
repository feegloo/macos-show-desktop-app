#!/bin/sh

open /System/Applications/Mission\ Control.app --args 1
